let timer3 = 30;
let score2 = 0;
var particles = [];
let showtip = false;
let tip = "";
function setup() {
  createCanvas(1000, 500);
  particles[0] = new Particle(100, 100);
  particles[1] = new Particle(300, 100);
  particles[2] = new Particle(500, 100);
  particles[3] = new Particle(700, 100);
}

function draw() {
  background(200, 255, 200);
  for (let i = 0; i < 4; i++) {
    particles[i].draw();
    particles[i].update();
  }

  textSize(22);
  textStyle(BOLD);
  textFont("Georgia");
  text("Pop all of the Even balloons!", 100, 400);
  text("Recovery Rush GAME 4", 100, 450);
  text("Balloon Math Game", 100, 500);

  text("Score:" + score2, width - 110, 50);

  textSize(80);

  if (showtip) {
    textSize(40);
    text(tip, width / 1.5, height / 1.5);
  }
  text(timer3, width / 1.5, height / 1.1);
  if (frameCount % 60 == 0 && timer3 > 0) {
    timer3--;
  }
  if (timer3 == 0) {
    showtip = false;
    textSize(40);
    text("GAME OVER", width / 1.5, height / 1.5);
    // noLoop()
  }
}

function mouseClicked() {
  for (let i = 0; i < 4; i++) {
    if (dist(mouseX, mouseY, particles[i].pos.x, particles[i].pos.y) < 50) {
      if (particles[i].target % 2 == 0) {
        score2 += 2;
        console.log("awesome");
        tip = "awesome";
      } else {
        if (score2 > 0) score2 -= 1;
        console.log("try again");
        tip = "try again";
      }

      showtip = true;
      particles[i].kk = true;
    }
  }
}

class Particle {
  constructor(p1, p2) {
    this.pos = createVector(p1, p2);
    this.size = 100;
    this.color = color(random(255), random(255), random(255));
    this.target = Math.floor(Math.random() * 89 + 10);
    this.kk = false;
  }
  draw() {
    fill(this.color);
    line(this.pos.x, this.pos.y, this.pos.x, this.pos.y + 200);
    circle(this.pos.x, this.pos.y, this.size);

    fill(0);

    textSize(32);
    text(this.target, this.pos.x, this.pos.y);
  }

  update() {
    if (this.kk) {
      this.size -= 1;

      if (this.size < 0) {
        this.kk = false;
        this.size = 100;
        this.target = Math.floor(Math.random() * 89 + 10);
        this.color = color(random(255), random(255), random(255));
      }
    }
  }
}