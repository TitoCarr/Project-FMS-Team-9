var gameOneStatus;
var gameTwoStatus;
var gameThreeStatus;
var gameFourStatus;
var menuScreen;


var userX;
var userY;
var userR = 30;

var c1x;
var c1y;
var c1r = 20;

var c2x;
var c2y;
var c2r = 20;

var c3x;
var c3y;
var c3r = 20;

var c4x;
var c4y;
var c4r = 20;

var score = 0;


//GAME TWO CODE
let X = 75;
let Y = 70;
let mazeL;
let color = ('red');
let value = 'yellow';
let timer = 30
var x,y; 





function setup() {
  createCanvas(440, 490);
  gameOneStatus = 0;
  gameTwoStatus = 0;
  gameThreeStatus = 0;
  gameFourStatus = 0;
  menuScreen = 0;
  }


function draw()   {
  clear();
  //****WORK IN PROGRESS MENU SCREEN, FIXME I WANNA BE PRETTY****
  if (menuScreen == 0)   {
    background(0)
    stroke(255);
    textSize(17)
    fill('rgb(218,159,53)')
    text('Recovery Rush', 160, 75);
    fill('white')
    text('Esc key for main menu', 140,400);

  }
  if (menuScreen == 1)   {
    setup();
  }
  //*************************************************************
  
  //***BELOW IS ALL OF THE CODE FOR STARTING GAME ONE***
  if (gameOneStatus == 0)   {
    stroke(255);
    fill('red');
    text('Press 1 to start game one', 20, 150);
    text('for Tracing Game', 20, 170);
  }
  if (gameOneStatus == 1) {
    let playerOne;
    var score = 0;
    var checkTwo;
    var checkThree;
    var checkFour;
    
    createCanvas(400, 400);
    background(0);
    fill(255);
    rect(120,50,150,40);
    fill(0);
    text('Tracing Shapes', 155, 75);
    
    userX = mouseX;
    userY = mouseY;
   
    fill(255);  
    playerOne = ellipse(userX, userY, userR,userR);
    
      square(150,180,100);
      c1x = 155;
      c1y = 180;
      
      c2x = 245;
      c2y = 180;
      
      c3x = 155;
      c3y = 280;
      
      c4x = 245;
      c4y = 280;
      
      var cOneXDist = c1x - userX;
      var cOneYDist = c1y - userY;
      var cOneDist = sqrt(cOneXDist * cOneXDist + cOneYDist * cOneYDist) - (c1r/2 + userR/2);
      
      var cTwoXDist = c2x - userX;
      var cTwoYDist = c2y - userY;
      var cTwoDist = sqrt(cTwoXDist * cTwoXDist + cTwoYDist * cTwoYDist) - (c2r/2 + userR/2);
      
      var cThreeXDist = c3x - userX;
      var cThreeYDist = c3y - userY;
      var cThreeDist = sqrt(cThreeXDist * cThreeXDist + cThreeYDist * cThreeYDist) - (c3r/2 + userR/2);
      
      var cFourXDist = c4x - userX;
      var cFourYDist = c4y - userY;
      var cFourDist = sqrt(cFourXDist * cFourXDist + cFourYDist * cFourYDist) - (c4r/2 + userR/2);
      
        if(cOneDist > 0)   {
            fill(252,73,3);
            score += 1;
          } else   {
            fill(3,252,107);
          }
        ellipse(c1x, c1y, c1r, c1r);
    
        if(cTwoDist <= 0)   {
            fill(3,252,107);
            score += 1;
          } else {
            fill(252,73,3);
          }
        ellipse(c2x, c2y, c2r, c2r);
        if(cThreeDist <= 0)   {
            fill(3,252,107);
            score += 1;
          } else {
            fill(252,73,3);
          }
        ellipse(c3x, c3y, c3r, c3r);
        if(cFourDist <= 0)   {
            fill(3,252,107);
            score += 1;
          } else {
            fill(252,73,3);
          }
        ellipse(c4x, c4y, c4r, c4r);
   }
    
    if (gameOneStatus == 9)   {
      text('',0,0);
    }
  //***************************************************  
  //***BELOW IS ALL OF THE CODE FOR STARTING GAME TWO***
  if (gameTwoStatus == 0)   {
    stroke(255);
    fill('blue')
    text('Press 2 to start game two', 230, 150);
    text('for Maze Game', 230, 170);

  }
  if (gameTwoStatus == 1)   {
    text('',0,0);
    createCanvas(660,660);
    background('rgb(189,214,251)')
    rect(250,50,160,40);
    fill(0);
    textSize(15);
    text('Maze Game', 290, 75)
    fill('blue')
    textSize(22);
    textStyle(BOLD);
    textFont('Georgia');
    fill('Blue');  
    textSize(22);
    text('Recovery Rush', 450, 30)
    text('GAME 2', 530, 60)
    fill('Red');  
    text('START HERE', 30, 50)
    fill('Green');  
    text('END HERE', 530, 630)
    fill('blue');
    text('Avoid the wall and pass the maze', 40, 600);
    text('use arrow keys to move', 40, 640)
    
    textSize(80);
    fill('red');
    text(timer, width/6, height/1.2);
    if (frameCount % 60 == 0 && timer > 0) {
    timer --;
    }
    if (timer == 0) {
    textSize(100);
    fill('black');
    text("GAME OVER", width/290, height/1.9); 
  }
    fill(color);
    
  {
  
    if (keyIsDown(LEFT_ARROW)) {
        fill('yellow');
        x= X-= 2;
    }
  
    if (keyIsDown(RIGHT_ARROW)) {
         fill('yellow');
        x= X+= 2;
    }
  
    if (keyIsDown(UP_ARROW)) {
        fill('yellow');
        y= Y-= 2;
    }
  
    if (keyIsDown(DOWN_ARROW)) {
        fill('yellow');
        y= Y+= 2;
    }   
    ellipse(X, Y, 19, 19);
  } 
  
    fill('black');
    rect(50,60,5,60)
    rect(100,60, 5, 20);  
    rect(50,120, 50, 5);
    rect(100,80, 50, 5);
    rect(150, 80, 5, 235);
    rect(100,120, 5, 140);
    rect(15, 260, 90, 5);
    rect(60,310, 90, 5);
    rect(10,260,5,200)
    rect(60,310,5,105)
    rect(62,410, 95, 5);
    rect(10, 460, 140, 5);
    rect(150,190, 5, 90);
    rect(150,460,100,5)
    rect(155,410,50,5);
    rect(200,230, 5, 180);
    rect(250,280, 5, 185);
    rect(200,230,180,5);
    rect(250,280,80,5);
    rect(330,280, 5, 110);
    rect(380,230, 5, 120);
    rect(330,390,135,5);
    rect(380,350,140,5);
    rect(460,390,5, 65);
    rect(520,350,5, 140);
    rect(360,490,165,5);
    rect(300,450,160,5);
    rect(300,450,5, 120);
    rect(360,490,5, 40);
    rect(360,530,120,5);
    rect(300,570,130,5);
    rect(475,530,5, 75);
    rect(430,570,5, 80);
    rect(430,645,110,5);
    rect(480,600,60,5);      
       
      
    
    if(X == 50 && X == 60 && Y == 5 && Y == 60) {    
    safe = false;
    ready = 0;
    text('You Lose', 150,300);  
  }
    
    
    
     if(X > width || X < 0 || Y > height || Y < 2) {
    safe = false;
    text('You Lose', 150,300);   
  }   
    d = int(dist(x, y, 560, 650));
    // calculate the distance between the ninja and numchucks x1, y1, x2, y2
    
     if (d <60) {
    text('You win!', 150, 300);
    //go to different levels
  }    
    
  }
  
  //***************************************************
  
  //***BELOW IS ALL OF THE CODE FOR STARTING GAME THREE***
    if (gameThreeStatus == 0)   {
      stroke(255);
      fill('yellow')
      text('Press 3 to start game three', 20, 300);
      text('for Shapes Game', 20, 320);

      }
    if (gameThreeStatus == 1)   {
      text('',0,0);
      createCanvas(670,670);
      background('rgb(240,240,184)');
      fill('black');
      rect(50, 160, 5, 260);
      rect(190, 160, 5, 260);
      rect(330, 160, 5, 260);
      rect(470, 160, 5, 260);
      rect(50, 160, 425, 5);
      rect(50, 200, 425, 5);
      rect(50, 420, 425, 5);
      textSize(80);
      text(timer, width/1.3, height/5);
      if(frameCount % 60 == 0 && timer > 0) { 
        timer --;
      }
      if(timer == 0) {
        textSize(20);
        textStyle(BOLD);
        textFont('Georgia');
        fill('red')
        text("GAME OVER", width/1.3, height/4);
      }

  
      fill('purple');
      textSize(20);
      text('Recovery Rush', 70, 50)
      text('Matching colours', 70, 90)
      text('GAME 3', 70, 130)
  
      fill('blue')
      text('Blue', 90, 190)
      fill('red')
      text('Red', 240, 190)
      fill('rgb(13,177,13)')
      text('Green', 370, 190)
  
      fill('rgb(30,226,30)')
      arc(50, 500, 80, 80, 0, PI + QUARTER_PI);
      fill('rgb(9,237,9)')
      ellipse(340, 500, 55, 55);
      fill('blue')
      arc(130, 480, 100, 100, 0, HALF_PI);
      fill('red')
      arc(250, 500, 80, 80, 0, PI + QUARTER_PI, CHORD);
      fill('blue')
      square(400, 470, 55, 20, 15, 10, 5);
      fill('red')
      square(490, 470, 55); 
      }
      if (gameThreeStatus == 9)   {
      
      }
  //***************************************************
  
  //***BELOW IS ALL OF THE CODE FOR STARTING GAME FOUR***
    if (gameFourStatus == 0)   {
      fill(255);
      fill('green')
      text('Press 4 to start game four', 230, 300);
      text('for Balloon Game', 230, 320);

      }
    if (gameFourStatus == 1)   {
      createCanvas(400,400);
      background('green');
      fill(255);
      rect(120,50,150,40);
      fill(0);
      text('Game Four', 165, 75)
      }
    if (gameFourStatus == 9)   {
      text('',0,0);
      }
  //***************************************************
  }


//****BELOW IS ALL OF THE CODE FOR THE KEY INPUTS FROM THE USER****
function keyPressed()   {
  if (key === '1')   {
    gameOneStatus = 1;
    gameTwoStatus = 9;
    gameThreeStatus = 9;
    gameFourStatus = 9;
  }
  if (key === '2')   {
    gameTwoStatus = 1;
    gameOneStatus = 9;
    gameThreeStatus = 9;
    gameFourStatus = 9;
  }
  if (key === '3')   {
    gameThreeStatus = 1;
    gameOneStatus = 9;
    gameTwoStatus = 9;
    gameFourStatus = 9;
  }
  if (key === '4')   {
    gameFourStatus = 1;
    gameOneStatus = 9;
    gameTwoStatus = 9;
    gameThreeStatus = 9;
  }
  if (keyCode === ESCAPE)   {
    menuScreen = 1;
  }
}
//*****************************************************************


